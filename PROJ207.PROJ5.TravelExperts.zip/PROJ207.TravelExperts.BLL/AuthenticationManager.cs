﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PROJ207.TravelExperts.Models;

namespace PROJ207.TravelExperts.BLL
{
    public class AuthenticationManager
    {
        public static CustomerDTO Authenticate(string username, string password)
        {
            CustomerDTO dto = null;

            var db = new TravelExpertsContext();
            var auth = db.Customers.SingleOrDefault(a => a.CustUserId == username && a.CustPassword == password);

            if (auth != null)
            {
                dto = new CustomerDTO
                {
                    custId = auth.CustomerId,
                    custUserId = auth.CustUserId,
                    custPW = auth.CustPassword
                };
            }
            return dto;
        }
    }
}
