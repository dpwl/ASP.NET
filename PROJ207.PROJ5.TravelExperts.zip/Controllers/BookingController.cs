﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PROJ207.TravelExperts.Models;

namespace PROJ207.TravelExperts.Controllers
{
    public class BookingController : Controller
    {
        private readonly TravelExpertsContext _context;

        public BookingController(TravelExpertsContext context)
        {
            _context = context;
        }

        // GET: Booking
        public async Task<IActionResult> Index()
        {
            var multitable = from bd in _context.Set<BookingDetails>()
                             join b in _context.Set<Bookings>()
                             on bd.BookingId equals b.BookingId into grouping
                             from b in grouping.DefaultIfEmpty()
                             select new MultipleClass
                             {
                                 custId = (int)b.CustomerId,
                                 bookingId = (int)bd.BookingId,
                                 itineryNo = (int)bd.ItineraryNo,
                                 tripStart = (DateTime)bd.TripStart,
                                 tripEnd = (DateTime)bd.TripEnd,
                                 description = bd.Description,
                                 destination = bd.Destination,
                                 basePrice = (decimal)bd.BasePrice,
                                 agencyCom = (decimal)bd.AgencyCommission,
                                 unitPrice = (decimal)bd.BasePrice + (decimal)bd.AgencyCommission,
                                 travelerCount = (double)b.TravelerCount,
                                 totalPrice = (decimal)(bd.BasePrice + bd.AgencyCommission) * (decimal)b.TravelerCount
                             };

            if (User.Identity.IsAuthenticated)
            {
                return View(await multitable.Where(a => a.custId.ToString() == User.FindFirst("custId").Value).ToListAsync());
            }
            else
            {
                return RedirectToAction("Login","Account");
            }
        }
    }
}
