﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PROJ207.TravelExperts.Models
{
    public class MultipleClass
    {
        public int custId { get; set; }
        [Display(Name ="Booking ID")]
        public int bookingId { get; set; }
        [Display(Name = "Itinery No.")]
        public int itineryNo { get; set; }
        [Display(Name = "Trip Start Date"), DataType(DataType.Date)]
        public DateTime tripStart { get; set; }
        [Display(Name = "Trip End Date"), DataType(DataType.Date)]
        public DateTime tripEnd { get; set; }
        [Display(Name = "Description")]
        public string description { get; set; }
        [Display(Name = "Destination")]
        public string destination { get; set; }
        [Display(Name = "Base Price($)")]
        public decimal basePrice { get; set; }
        [Display(Name = "Agency Commission($)")]
        public decimal agencyCom { get; set; }
        [Display(Name = "Unit Price($)")]
        public decimal unitPrice { get; set; }
        [Display(Name = "Traveler Count")]
        public double travelerCount { get; set; }
        [Display(Name = "Total Price($)")]
        public decimal totalPrice { get; set; }

    }
}
