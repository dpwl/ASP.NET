﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace PROJ207.TravelExperts.Models
{
    public partial class Customers
    {
        public Customers()
        {
            Bookings = new HashSet<Bookings>();
            CreditCards = new HashSet<CreditCards>();
            CustomersRewards = new HashSet<CustomersRewards>();
        }

        [Key]
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "First Name is required."), Display(Name = "First Name*")]
        [StringLength(25)]
        public string CustFirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required."), Display(Name = "Last Name*")]
        [StringLength(25)]
        public string CustLastName { get; set; }

        [Required(ErrorMessage = "Address is required."), Display(Name = "Address*")]
        [StringLength(75)]
        public string CustAddress { get; set; }

        [Required(ErrorMessage = "City is required."), Display(Name = "City*")]
        [StringLength(50)]
        public string CustCity { get; set; }

        [Required(ErrorMessage = "Province is required."), Display(Name = "Province*")]
        [StringLength(2)]
        public string CustProv { get; set; }

        [Required(ErrorMessage = "Poastal code is required."), Display(Name = "Postal Code*")]
        [RegularExpression(@"[A-Za-z][0-9][A-Za-z] [0-9][A-Za-z][0-9]",
            ErrorMessage = "Invalid postal code format,e.g. T2R 0M8 - blank is MUST.")]
        [StringLength(7)]
        public string CustPostal { get; set; }

        [Required(ErrorMessage = "Country is required."), Display(Name = "Country*")]
        [StringLength(25)]
        public string CustCountry { get; set; }

        [Required(ErrorMessage = "Home or Cell phone number is required."), Display(Name = "Home/Cell Phone*")]
        [RegularExpression(@"[0-9]{3}[0-9]{3}[0-9]{4}", 
            ErrorMessage = "Invalid phone number format, e.g. 4031238877, NO special characters.")]
        [StringLength(20)]
        public string CustHomePhone { get; set; }

        [Display(Name = "Business Phone")]
        [StringLength(20)]
        public string CustBusPhone { get; set; }

        [Display(Name = "Email")]
        [StringLength(50)]
        public string CustEmail { get; set; }

        [Required(ErrorMessage = "User ID is required."), Display(Name = "User ID*")]
        [Column("CustUserID")]
        [StringLength(25)]
        public string CustUserId { get; set; }

        [Required(ErrorMessage = "Password is required."), Display(Name = "Password*")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ -/:-@\[-`{-~]).{6,15}$", 
            ErrorMessage = "Total 6 - 15 characters including at least one lowercase, one uppercase, one number, and one special character.")]
        [StringLength(25)]
        public string CustPassword { get; set; }

        [Required(ErrorMessage = "Confirm Password is required."), Display(Name = "Confirm Password*")]
        [Compare("CustPassword",ErrorMessage ="Password does not match. Please try again.")]
        [StringLength(25)]
        public string ConfirmPassword { get; set; }

        public int? AgentId { get; set; }

        [ForeignKey(nameof(AgentId))]
        [InverseProperty(nameof(Agents.Customers))]
        public virtual Agents Agent { get; set; }
        [InverseProperty("Customer")]
        public virtual ICollection<Bookings> Bookings { get; set; }
        [InverseProperty("Customer")]
        public virtual ICollection<CreditCards> CreditCards { get; set; }
        [InverseProperty("Customer")]
        public virtual ICollection<CustomersRewards> CustomersRewards { get; set; }
    }

    //public class UserManager
    //{
    //    public static Customers Authenticate(string username, string password)
    //    {
    //        var db = new TravelExpertsContext();
    //        var auth = db.Customers.SingleOrDefault(a => a.CustUserId == username && a.CustPassword == password);
    //        return auth;
    //    }
    //}
}
