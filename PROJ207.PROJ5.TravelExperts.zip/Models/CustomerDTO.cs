﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PROJ207.TravelExperts.Models
{
    public class CustomerDTO
    {
        public int custId { get; set; }
        public string custUserId { get; set; }
        public string custPW { get; set; }
    }
}
